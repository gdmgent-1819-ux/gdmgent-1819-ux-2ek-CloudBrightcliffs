# Eindopdracht UX

- Voornaam: Eveline
- Familienaam: Bonte
- Studentnummer: 104805
- Klasgroep: 1MMPa
- UX prototype link: https://xd.adobe.com/view/141cebb4-4eda-4268-758f-089cc62d107e-622d/?fullscreen
